<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Surat Jalan</h1>
        </div>

        <div class="card">
            <div class="card-header">
                <a href=<?php echo e(url('tambahpengiriman')); ?>>
                    <button type="button" class="btn btn-primary my-auto">
                        Tambah Data
                    </button>
                </a>
            </div>
            <div class="card-body">
                <table id="tabelSuratJalan" class="table table-bordered table-no-wrap table-responsive" style="width:100%">
                    <thead>
                        <tr>
                            <th>No.</th>
                            <th>No. SPK</th>
                            <th>No. Surat Jalan</th>
                            <th>Qty</th>
                            <th>Nama Penerima</th>
                            <th>Alamat Penerima</th>
                            <th>Penerimaan</th>
                            <th>Aksi</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $ctr = 1; ?>
                        <?php $__currentLoopData = $pengiriman; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($ctr); ?></td>
                                <td><?php echo e($prm->no_spk); ?></td>
                                <td><?php echo e($prm->no_surat_jalan); ?></td>
                                <td><?php echo e($prm->qty); ?></td>
                                <td><?php echo e($prm->nama_penerima); ?></td>
                                <td><?php echo e($prm->alamat_penerima); ?></td>
                                <td>
                                    <button type="button" class="btn btn-success"
                                        onclick="btnAcc('<?php echo e($prm->no_spk); ?>');window.location.reload();"><i
                                            class="fas fa-check"></i></button>
                                    <button type="button" class="btn btn-danger"
                                        onclick="btnDecline('<?php echo e($prm->no_spk); ?>');window.location.reload();"><i
                                            class="fas fa-times"></i></button>
                                </td>
                                <td>

                                    <button type="button" onclick="btnedit(<?php echo e($prm); ?>)" style="margin-right: 5px;" class="btn btn-warning"
                                        data-toggle="modal" data-target="#exampleModal">
                                        <i class="fas fa-edit"></i>

                                        <form action="<?php echo e(url('suratjalan/delete/' . $prm->no_spk)); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <button type="submit" class="btn btn-danger"><i class="fas fa-trash"></i></button>
                                        </form>
                                    </button>
                                    <!-- Modal -->
                                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog"
                                        aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">
                                                        Edit Surat Jalan
                                                    </h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                        aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body text-left">
                                                    <form action="<?php echo e(url('/doEditSuratJalan')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <div class="form-group">
                                                            <input type="hidden" name="no_spk">
                                                            <label class="label">No. Surat Jalan</label>
                                                            <input class="form-control"
                                                                placeholder="Masukkan No. Surat Jalan"
                                                                name="no_surat_jalan" >

                                                            <label for="exampleFormControlTextarea1" class="label">Nama
                                                                Penerima</label>
                                                            <input class="form-control" placeholder="Masukkan Nama Penerima"
                                                                name="nama_penerima">

                                                            <label for="exampleFormControlTextarea1" class="label">Alamat
                                                                Penerima</label>
                                                            <input class="form-control"
                                                                placeholder="Masukkan Alamat Lengkap Penerima"
                                                                name="alamat_penerima">

                                                            <label for="exampleFormControlTextarea1"
                                                                class="label">Qty</label>
                                                            <input type="number" class="form-control"
                                                                placeholder="Masukkan Jumlah" name="qty">

                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary"
                                                                data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-primary">Update</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>



                                </td>

                                 <?php if($prm->status_pengiriman ==1): ?>
                                    <td>Diterima</td>
                                <?php else: ?>
                                    <td>Ditolak</td>
                                <?php endif; ?>
                            </tr>
                            <?php $ctr++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
    <script>
        function btnAcc(id) {
            $.ajax({
                url: "autocomplete.php",
                method: "POST",
                data: {
                    query: id,
                    ctr: "AccPengiriman"
                },
                success: function(data) {

                }
            });
        }

        function btnDecline(id) {
            $.ajax({
                url: "autocomplete.php",
                method: "POST",
                data: {
                    query: id,
                    ctr: "DeclinePengiriman"
                },
                success: function(data) {

                }
            });
        }
        function btnedit(pengiriman)
        {
                $("[name='no_spk']").val(pengiriman['no_spk']);
                $("[name='no_surat_jalan']").val(pengiriman['no_surat_jalan']);
                $("[name='nama_penerima']").val(pengiriman['nama_penerima']);
                $("[name='alamat_penerima']").val(pengiriman['alamat_penerima']);
                $("[name='qty']").val(pengiriman['qty']);
            }
    </script>
    <!-- /.container-fluid -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sugha\OneDrive\Dokumen\PaperUs\newPaperUs\resources\views/suratjalan.blade.php ENDPATH**/ ?>