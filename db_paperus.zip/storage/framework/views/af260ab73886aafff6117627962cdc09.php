<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-800">Form Desain dan Pisau</h1>
        </div>
        <div class="form-group">
            <form action="<?php echo e(url('/doAddDesain')); ?>" method="post">
                <?php echo csrf_field(); ?>
                <label class="label" for="readonlyTextInput">No. Penawaran</label>
                <select data-live-search="true" class="selectpicker form-control" name="id_penawaran"
                    onchange="nama_brand_change()">
                    <option selected>Pilih No. Penawaran</option>
                    <?php $__currentLoopData = $pembayaran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($prm->id_penawaran); ?>><?php echo e($prm->id_penawaran); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
                <label class="label">Customer</label>
                <input class="form-control" name="pic" placeholder="Customer">

                <label class="label">Jenis Box</label>
                <input class="form-control" name="jenis_box" placeholder="Jenis Box">

                <label class="label">Link Desain</label>
                <input class="form-control" name="link" placeholder="Link Desain">

                <label class="label" for="readonlyTextInput">Jenis Pisau</label>
                <select data-live-search="true" class="selectpicker form-control" name="pisau">
                    <option selected>Pilih Jenis Pisau</option>
                    <?php $__currentLoopData = $pisau; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($prm->namabarang); ?>><?php echo e($prm->namabarang); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <label class="label" for="readonlyTextInput">Jenis Plat</label>
                <select data-live-search="true" class="selectpicker form-control" name="plat">
                    <option selected>Pilih Jenis Plat</option>
                    <?php $__currentLoopData = $plat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value=<?php echo e($prm->namabarang); ?>><?php echo e($prm->namabarang); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>

                <br>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
        </div>
    </div>
    <script>
        function nama_brand_change() {
            $.ajax({
                url: "autocomplete.php",
                method: "POST",
                data: {
                    query: $("[name='id_penawaran']").val(),
                    ctr: "DesainCustomer"
                },
                success: function(data) {
                    var temp = data.split(",");
                    $("[name='pic']").val(temp[0]);
                    $("[name='jenis_box']").val(temp[1]);
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sugha\OneDrive\Dokumen\PaperUs\newPaperUs\resources\views/tambahdesain.blade.php ENDPATH**/ ?>