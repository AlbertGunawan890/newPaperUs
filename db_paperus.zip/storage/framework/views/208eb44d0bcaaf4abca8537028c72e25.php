<?php $__env->startSection('content'); ?>
    <!-- Begin Page Content -->
    <div class="container-fluid">
        <?php if(Session::has('error')): ?>
            <p class="alert "> <?php echo e(Session::get('error')); ?></p>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sugha\OneDrive\Dokumen\PaperUs\newPaperUs\resources\views/home.blade.php ENDPATH**/ ?>